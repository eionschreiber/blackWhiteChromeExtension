

function click(){
  chrome.tabs.executeScript(null,

  {code:"document.body.style.filter=grayscale(100%)"});
  window.close();
}

document.addEventListener('DOMContentLoaded', function(){
  var body = document.querySelector('body');
  body.addEventListener("click", click);
});
